# -*- coding: utf-8 -*-
"""Offline check for tools/lobby_nickname_2022.py using the bundled lobby blob."""
import re
import struct
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
from roe_protocol_2022 import dt_plain, decrypt, encrypt  # noqa: E402
from lobby_nickname_2022 import LobbyNicknameStream  # noqa: E402

key = (ROOT / 'private' / 'candidate-001.key').read_bytes()
src = (ROOT / 'search' / 'Ring-of-Elysium-Lobby-Emulator' / 'LobbyEmulator' / 'Logic' / 'LobbyPreData.cs').read_text(encoding='utf-8')
blobs = re.findall(r'"([0-9A-F]{32,})"', src)
cipher = bytes.fromhex(blobs[2])


def frame(body, cmd=0):
    return b'\x55\x0e' + bytes([cmd, 0]) + struct.pack('>II', 12, len(body)) + body


fails = []


def check(name, cond, detail=''):
    print(('PASS ' if cond else 'FAIL ') + name + ('' if cond else f' -> {detail}'))
    if not cond:
        fails.append(name)


# 1. plain blob contains the hard-coded name
plain = decrypt(cipher, key)
check('原始帧含 BRING_BACK_ROE!!', b'BRING_BACK_ROE!!' in plain)

# 2. patch to a longer name
stream = LobbyNicknameStream(key, 'baoshayahuan')
out, updates = stream.feed(frame(cipher))
check('发生一次替换', len(updates) == 1, updates)

head, body_len = struct.unpack_from('>II', out, 4)
check('bodyLen 与实际一致', head + body_len == len(out), (head, body_len, len(out)))
patched = dt_plain(out, key)
check('新名字在流里', b'baoshayahuan' in patched)
check('旧名字已消失', b'BRING_BACK_ROE!!' not in patched)
check('长度字节正确', patched[patched.find(b'baoshayahuan') - 1] == len('baoshayahuan') + 1)
check('名字后仍是 NUL', patched[patched.find(b'baoshayahuan') + len('baoshayahuan')] == 0)
check('前缀未被破坏', patched[:10] == plain[:10])

# 3. short name still keeps the frame parseable
stream2 = LobbyNicknameStream(key, 'bob')
out2, updates2 = stream2.feed(frame(cipher))
head2, body2 = struct.unpack_from('>II', out2, 4)
check('短名字 bodyLen 一致', head2 + body2 == len(out2), (head2, body2, len(out2)))
check('短名字写入', b'bob' in dt_plain(out2, key))

# 4. chunked delivery (frame split across TCP reads)
stream3 = LobbyNicknameStream(key, 'splitname')
packet = frame(cipher)
part1, u1 = stream3.feed(packet[:100])
part2, u2 = stream3.feed(packet[100:])
check('分片输入无输出', part1 == b'' and u1 == [])
check('分片补全后替换', len(u2) == 1 and b'splitname' in dt_plain(part2, key))

# 5. unrelated frame untouched
other = frame(encrypt(b'\x00' * 16 + b'hello', key))
out4, u4 = LobbyNicknameStream(key, 'baoshayahuan').feed(other)
check('无关帧不修改', out4 == other and u4 == [])

print('\n%d failed' % len(fails))
raise SystemExit(1 if fails else 0)
