'use strict';

const state = {
  status: null, schema: null, values: {}, accounts: [], bindings: {}, host: null,
  rooms: [], configs: [], activeLog: null, tab: 'dashboard', dirty: false,
};

// --------------------------------------------------------------------- helpers
async function api(path, options = {}) {
  const res = await fetch(path, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
    body: options.body ? JSON.stringify(options.body) : undefined,
  });
  const text = await res.text();
  let data = {};
  try { data = text ? JSON.parse(text) : {}; } catch (e) { data = { raw: text }; }
  if (!res.ok) throw new Error(data.error || res.statusText);
  return data;
}

function toast(msg, isError = false) {
  const box = document.getElementById('toast');
  const el = document.createElement('div');
  el.className = 'toast' + (isError ? ' err' : '');
  el.textContent = msg;
  box.appendChild(el);
  setTimeout(() => el.remove(), 3800);
}

function h(tag, attrs = {}, ...children) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (k === 'class') el.className = v;
    else if (k === 'html') el.innerHTML = v;
    else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else if (v !== null && v !== undefined) el.setAttribute(k, v);
  }
  for (const c of children.flat()) {
    if (c === null || c === undefined) continue;
    el.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
  }
  return el;
}

function fmtUptime(sec) {
  if (!sec) return '';
  const m = Math.floor(sec / 60), s = sec % 60;
  return `${m} 分 ${s} 秒`;
}

// ------------------------------------------------------------------- navigation
document.getElementById('nav').addEventListener('click', (ev) => {
  const btn = ev.target.closest('button[data-tab]');
  if (!btn) return;
  document.querySelectorAll('#nav button').forEach(b => b.classList.toggle('active', b === btn));
  document.querySelectorAll('section.tab').forEach(s => s.classList.toggle('active', s.id === 'tab-' + btn.dataset.tab));
  state.tab = btn.dataset.tab;
  if (state.tab === 'logs') refreshLogs();
  if (state.tab === 'configs') loadConfigList();
  if (state.tab === 'live') loadLive();
});

// ---------------------------------------------------------------------- status
async function poll() {
  try {
    const s = await api('/api/status');
    state.status = s;
    state.accounts = s.accounts || [];
    state.bindings = s.bindings || {};
    state.host = s.host_account;
    state.rooms = s.rooms || [];
    renderTop(s);
    renderDashboard(s);
    renderAccounts();
    renderRooms();
    if (state.tab === 'live') loadLive();
  } catch (e) {
    console.warn(e);
  }
}

function renderTop(s) {
  const pill = document.getElementById('pill-server');
  const on = s.server.running;
  pill.classList.toggle('on', on);
  pill.classList.toggle('bad', !on);
  pill.lastElementChild.textContent = on ? `服务端运行中 · PID ${s.server.pid}` : '服务端未运行';

  const ports = s.server.ports || {};
  const p = document.getElementById('pill-ports');
  const open = Object.entries(ports).filter(([, v]) => v).map(([k]) => k);
  p.textContent = `端口 ${open.length ? open.join(' / ') : '未监听'}`;
  p.classList.toggle('on', open.length === 3);
  p.classList.toggle('bad', open.length === 0);

  document.getElementById('clientdir').textContent = '客户端: ' + (s.client_dir || '未设置');
}

function renderDashboard(s) {
  document.getElementById('dash-state').textContent = s.server.running ? '运行中' : '未运行';
  document.getElementById('dash-run').textContent = s.server.run
    ? `本次记录: ${s.server.run.split('\\').pop()}` + (s.server.uptime ? ` · ${fmtUptime(s.server.uptime)}` : '')
    : '还没有启动记录';
  document.getElementById('dash-clients').textContent = `${(s.clients || []).filter(c => c.running).length} 个客户端`;
  document.getElementById('dash-host').textContent = s.host_account || '-';
  document.getElementById('dash-acc-count').textContent = (s.accounts || []).length;
  const binds = Object.entries(s.bindings || {}).map(([ip, n]) => `${ip} → ${n}`);
  document.getElementById('dash-bindings').textContent = binds.length ? binds.join('，') : '尚未设置 IP 绑定';

  const ipSel = document.getElementById('client-ip');
  const current = ipSel.value;
  ipSel.innerHTML = '';
  const ips = ['127.0.0.1', ...(s.ips || [])];
  for (const ip of [...new Set(ips)]) ipSel.appendChild(h('option', { value: ip }, ip));
  ipSel.value = current || '127.0.0.1';

  if (s.server.events && s.server.events.endpoint) {
    const e = s.server.events.endpoint;
    document.getElementById('dash-events').textContent =
      Object.entries(e).filter(([k]) => !['recv', 'send', 'data'].includes(k))
        .slice(0, 8).map(([k, v]) => `${k}:${v}`).join('  ');
  }
  const coopSel = document.getElementById('coop-ip');
  if (coopSel) {
    const cur = coopSel.value;
    coopSel.innerHTML = '';
    for (const ip of [...new Set(['127.0.0.1', ...(s.ips || [])])]) coopSel.appendChild(h('option', { value: ip }, ip));
    if (cur) coopSel.value = cur;
    else if ((s.ips || []).length) coopSel.value = s.ips[0];
  }
  if (state.tab === 'dashboard') tailStatusLog(s);
}

let lastRunShown = null;
async function tailStatusLog(s) {
  const path = s.server.log;
  if (!path) return;
  if (lastRunShown === path + s.server.uptime) return;
  lastRunShown = path + s.server.uptime;
  try {
    const d = await api('/api/logs/tail?n=40&path=' + encodeURIComponent(path));
    document.getElementById('dash-log').textContent = d.lines.join('\n');
  } catch (e) { /* ignore */ }
}

// --------------------------------------------------------------------- actions
document.getElementById('btn-start').onclick = async () => {
  try { const r = await api('/api/server/start', { method: 'POST', body: { host_only: false } });
    toast(`服务端启动中 (PID ${r.pid})，客户端会自动打开`); poll(); }
  catch (e) { toast(e.message, true); }
};
document.getElementById('btn-start-host').onclick = async () => {
  try { const r = await api('/api/server/start', { method: 'POST', body: { host_only: true } });
    toast(`主机模式启动 (PID ${r.pid})，其他机器可连接`); poll(); }
  catch (e) { toast(e.message, true); }
};
document.getElementById('btn-stop').onclick = async () => {
  if (!confirm('停止服务端？本局客户端会被关闭。')) return;
  try { await api('/api/server/stop', { method: 'POST' }); toast('已停止'); poll(); }
  catch (e) { toast(e.message, true); }
};
document.getElementById('btn-client').onclick = async () => {
  try {
    const ip = document.getElementById('client-ip').value;
    const port = document.getElementById('client-port').value || 8001;
    const r = await api('/api/client/launch', { method: 'POST', body: { ip, port } });
    toast(`客户端启动 PID ${r.pid}`); poll();
  } catch (e) { toast(e.message, true); }
};
document.getElementById('btn-client-stop').onclick = async () => {
  try { await api('/api/client/stop', { method: 'POST' }); toast('客户端已关闭'); poll(); }
  catch (e) { toast(e.message, true); }
};

// -------------------------------------------------------------------- settings
function fieldControl(field) {
  const id = 'fld-' + field.key;
  let input;
  if (field.type === 'bool') {
    input = h('input', { type: 'checkbox', id });
    input.checked = !!state.values[field.key];
  } else if (field.type === 'select') {
    input = h('select', { id });
    for (const opt of field.options) {
      input.appendChild(h('option', { value: String(opt) }, String(opt)));
    }
    input.value = String(state.values[field.key]);
  } else if (field.type === 'int') {
    input = h('input', { id, type: 'number', min: field.options.min, max: field.options.max });
    input.value = state.values[field.key];
  } else {
    input = h('input', { id, type: 'text' });
    input.value = state.values[field.key] ?? '';
  }
  input.addEventListener('change', () => {
    state.values[field.key] = field.type === 'bool' ? input.checked
      : field.type === 'int' ? Number(input.value) : input.value;
    saveSettings();
  });
  return h('div', { class: 'field' },
    h('label', {}, field.label, h('span', { class: 'help' }, field.help + (field.cli ? `  ·  ${field.cli}` : ''))),
    input);
}

let saveTimer = null;
function saveSettings() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(async () => {
    try {
      const r = await api('/api/settings', { method: 'POST', body: { values: state.values } });
      state.values = r.values;
      toast('设置已保存（重启服务端后生效）');
    } catch (e) { toast(e.message, true); }
  }, 350);
}

async function loadSettings() {
  const d = await api('/api/settings');
  state.schema = d.schema;
  state.values = d.values;
  const host = document.getElementById('server-fields');
  host.innerHTML = '';
  const groups = h('div', { class: 'groups' });
  for (const g of d.schema.groups) {
    const fields = d.schema.fields.filter(f => f.group === g.id);
    if (!fields.length) continue;
    const box = h('div', { class: 'group' }, h('h3', {}, g.title));
    for (const f of fields) box.appendChild(fieldControl(f));
    groups.appendChild(box);
  }
  host.appendChild(groups);
}

document.getElementById('btn-preview').onclick = async () => {
  try {
    const d = await api('/api/server/preview');
    document.getElementById('cmd-preview').textContent = d.line;
  } catch (e) { toast(e.message, true); }
};
document.getElementById('btn-save-server').onclick = async () => {
  if (!confirm('保存设置并重启服务端？正在运行的客户端会被一并关闭。')) return;
  try {
    await api('/api/settings', { method: 'POST', body: { values: state.values } });
    await api('/api/server/stop', { method: 'POST' }).catch(() => {});
    const r = await api('/api/server/start', { method: 'POST', body: { host_only: false } });
    toast(`已重启服务端 PID ${r.pid}`);
    poll();
  } catch (e) { toast(e.message, true); }
};

document.getElementById('btn-coop').onclick = async () => {
  const ip = document.getElementById('coop-ip').value;
  if (!confirm('以双人联机模式开服？会切换到 0.0.0.0 + 对外 IP ' + ip + '，并关闭门/可破坏物。')) return;
  try {
    const r = await api('/api/coop/start', { method: 'POST', body: { ip, with_client: true } });
    document.getElementById('coop-cmd').textContent =
      '朋友的启动命令：\nEuropa_Client.exe ' + r.join + '\n（客户端目录任意，-server 指向 ' + r.ip + ':8001）';
    toast('双人联机服务端已启动');
    poll();
  } catch (e) { toast(e.message, true); }
};

// -------------------------------------------------------------------- accounts
function renderAccounts() {
  const tbody = document.querySelector('#acc-table tbody');
  if (!tbody) return;
  tbody.innerHTML = '';
  for (const acc of state.accounts) {
    const isHost = acc.name === state.host;
    const bindIp = Object.keys(state.bindings).find(ip => state.bindings[ip] === acc.name) || '';
    tbody.appendChild(h('tr', {},
      h('td', {}, acc.name + (isHost ? '  ⭐' : '')),
      h('td', { class: 'muted' }, '0x' + acc.actor_uid.toString(16)),
      h('td', {}, h('input', {
        value: bindIp, placeholder: 'IP', size: 14,
        onchange: async (ev) => {
          try {
            await api('/api/accounts/bind', { method: 'POST', body: { ip: ev.target.value.trim(), name: acc.name } });
            toast('绑定已更新'); poll();
          } catch (e) { toast(e.message, true); }
        },
      })),
      h('td', { class: 'muted' }, acc.note || ''),
      h('td', {},
        h('button', { onclick: async () => {
          try { await api('/api/accounts/host', { method: 'POST', body: { name: acc.name } }); toast('主机账户已切换'); poll(); }
          catch (e) { toast(e.message, true); }
        } }, isHost ? '主机' : '设为主机'),
        ' ',
        h('button', { class: 'danger', onclick: async () => {
          try { await api('/api/accounts/' + encodeURIComponent(acc.name), { method: 'DELETE' }); toast('账户已删除'); poll(); }
          catch (e) { toast(e.message, true); }
        } }, '删除'))));
  }
}

document.getElementById('btn-add-acc').onclick = async () => {
  const name = document.getElementById('new-acc-name').value.trim();
  const note = document.getElementById('new-acc-note').value.trim();
  try {
    await api('/api/accounts', { method: 'POST', body: { name, note } });
    document.getElementById('new-acc-name').value = '';
    document.getElementById('new-acc-note').value = '';
    toast('账户已添加'); poll();
  } catch (e) { toast(e.message, true); }
};

// ----------------------------------------------------------------------- rooms
const roomHost = document.getElementById('room-host');
function renderRooms() {
  if (roomHost && roomHost.dataset.count !== String(state.accounts.length)) {
    roomHost.dataset.count = String(state.accounts.length);
    const cur = roomHost.value;
    roomHost.innerHTML = '';
    for (const a of state.accounts) roomHost.appendChild(h('option', { value: a.name }, a.name));
    if (cur) roomHost.value = cur;
  }
  const box = document.getElementById('room-list');
  if (!box) return;
  box.innerHTML = '';
  if (!state.rooms.length) { box.appendChild(h('div', { class: 'muted' }, '还没有房间')); return; }
  for (const r of state.rooms) {
    box.appendChild(h('div', { class: 'room' },
      h('div', { class: 'name' }, r.name, ' ', h('span', { class: 'badge ' + r.status }, r.status)),
      h('div', { class: 'muted' }, `房主 ${r.host} · 模式 ${r.mode} · 地图 ${r.map} · ${r.members.length}/${r.max}`),
      h('div', { class: 'muted' }, '成员: ' + (r.members.join('、') || '—')),
      h('div', { class: 'row' },
        h('button', { class: 'primary', onclick: async () => {
          try {
            await api(`/api/rooms/${r.id}/start`, { method: 'POST' });
            toast('已标记开始：统一战局后端尚未实现（UI 已就绪）');
            poll();
          } catch (e) { toast(e.message, true); }
        } }, '开启同一战局'),
        h('select', { class: 'join-acc' },
          ...state.accounts.filter(a => !r.members.includes(a.name))
            .map(a => h('option', { value: a.name }, a.name))),
        h('button', { onclick: async (ev) => {
          const sel = ev.target.parentElement.querySelector('select.join-acc');
          if (!sel || !sel.value) return toast('没有可加入的账户', true);
          try {
            await api(`/api/rooms/${r.id}/join`, { method: 'POST', body: { account: sel.value } });
            toast(`${sel.value} 已加入房间`); poll();
          } catch (e) { toast(e.message, true); }
        } }, '加入'),
        h('button', { onclick: async () => {
          try { await api(`/api/rooms/${r.id}/reset`, { method: 'POST' }); poll(); } catch (e) { toast(e.message, true); }
        } }, '重置'),
        h('button', { class: 'danger', onclick: async () => {
          try { await api('/api/rooms/' + r.id, { method: 'DELETE' }); toast('房间已删除'); poll(); } catch (e) { toast(e.message, true); }
        } }, '删除'))));
  }
}

document.getElementById('btn-create-room').onclick = async () => {
  try {
    await api('/api/rooms', {
      method: 'POST',
      body: {
        name: document.getElementById('room-name').value,
        host: document.getElementById('room-host').value,
        max: Number(document.getElementById('room-max').value || 4),
      },
    });
    document.getElementById('room-name').value = '';
    toast('房间已创建'); poll();
  } catch (e) { toast(e.message, true); }
};

// --------------------------------------------------------------------- configs
async function loadConfigList() {
  const d = await api('/api/configs');
  state.configs = d.configs;
  const sel = document.getElementById('cfg-select');
  const cur = sel.value;
  sel.innerHTML = '';
  for (const c of d.configs) {
    const kb = (c.size / 1024).toFixed(1);
    sel.appendChild(h('option', { value: c.name }, `${c.name}  (${kb} KB)${c.read_only ? '  [只读]' : ''}`));
  }
  if (cur) sel.value = cur;
  if (!sel.dataset.bound) {
    sel.dataset.bound = '1';
    sel.addEventListener('change', () => loadConfig(sel.value));
  }
  if (sel.value) loadConfig(sel.value);
}

async function loadConfig(name) {
  const d = await api('/api/configs/' + encodeURIComponent(name));
  document.getElementById('cfg-text').value = d.text;
  const meta = state.configs.find(c => c.name === name);
  document.getElementById('cfg-meta').textContent =
    meta ? `${meta.file} · ${(meta.size / 1024).toFixed(1)} KB · 修改于 ${meta.modified}` : '';
  document.getElementById('btn-cfg-save').disabled = !!(meta && meta.read_only);
}

document.getElementById('btn-cfg-reload').onclick = () => loadConfigList();
document.getElementById('btn-cfg-save').onclick = async () => {
  const name = document.getElementById('cfg-select').value;
  try {
    await api('/api/configs/' + encodeURIComponent(name), {
      method: 'POST', body: { text: document.getElementById('cfg-text').value },
    });
    toast('已保存（旧文件已备份到 control/state/backups）');
    loadConfig(name);
  } catch (e) { toast(e.message, true); }
};

// ------------------------------------------------------------------ live control
async function loadLive() {
  try {
    const d = await api('/api/live/status');
    const state = document.getElementById('live-state');
    if (state) {
      state.textContent = d.enabled
        ? `已启用 · ${d.run ? d.run.split('\\').pop() : '还没有运行记录'}`
        : '未启用：到「服务器」页勾选「实时指令」并重启服务端';
      state.style.color = d.enabled ? '' : '#ffb4ae';
    }
    const sel = document.getElementById('live-player');
    if (sel) {
      const cur = sel.value;
      sel.innerHTML = '';
      sel.appendChild(h('option', { value: '' }, '全部 / 默认'));
      for (const p of (d.players || [])) {
        sel.appendChild(h('option', { value: p.uid }, `${p.name || '?'} · ${p.remote || ''}`));
      }
      if (cur) sel.value = cur;
    }
    const results = document.getElementById('live-results');
    if (results) {
      results.innerHTML = '';
      if (!d.results.length) results.appendChild(h('div', {}, '还没有执行记录'));
      for (const r of [...d.results].reverse()) {
        const ok = r.accepted === true;
        results.appendChild(h('div', { style: 'padding:3px 0;border-bottom:1px dashed #1d2837' },
          `${r.time || ''}  ${r.action}  `,
          h('span', { style: `color:${ok ? '#8ce99a' : '#ffb4ae'}` }, ok ? '已执行' : (r.reason || '拒绝')),
          r.hp != null ? `  hp=${r.hp}` : '',
          r.definition != null && r.quantity != null ? `  ${r.definition} +${r.quantity}` : ''));
      }
    }
    const queue = document.getElementById('live-queue');
    if (queue) {
      queue.textContent = d.queue.length
        ? d.queue.map(q => `${q.id}:${q.action}`).join('   ')
        : '空';
    }
  } catch (e) { /* panel offline */ }
}

async function liveAction(payload) {
  const sel = document.getElementById('live-player');
  if (sel && sel.value) payload.recipient = sel.value;
  try {
    const r = await api('/api/live/action', { method: 'POST', body: payload });
    toast(`已入队 ${r.id}`);
    loadLive();
  } catch (e) { toast(e.message, true); }
}

document.querySelectorAll('[data-live-hp]').forEach(btn => {
  btn.addEventListener('click', () => liveAction({ action: 'set_own_health', hp: Number(btn.dataset.liveHp) }));
});
document.getElementById('live-hp-apply').onclick = () =>
  liveAction({ action: 'set_own_health', hp: Number(document.getElementById('live-hp').value) });
document.getElementById('live-ammo-apply').onclick = () =>
  liveAction({ action: 'give_ammo', definition: Number(document.getElementById('live-ammo-def').value),
               quantity: Number(document.getElementById('live-ammo-qty').value) });
document.getElementById('live-npc-apply').onclick = () =>
  liveAction({ action: 'damage_npc', damage: Number(document.getElementById('live-npc-dmg').value) });
document.getElementById('live-kill').onclick = () => {
  if (confirm('击杀当前角色（0x533 终局死亡）？')) liveAction({ action: 'kill_self' });
};
document.getElementById('live-revive').onclick = () => liveAction({ action: 'revive_self' });

// ------------------------------------------------------------------------ logs
async function refreshLogs() {
  const d = await api('/api/logs');
  const list = document.getElementById('log-list');
  list.innerHTML = '';
  for (const l of d.logs) {
    const el = h('div', { title: l.path }, `${l.name} · ${(l.size / 1024).toFixed(0)}KB`);
    el.onclick = async () => {
      document.querySelectorAll('#log-list div').forEach(x => x.classList.remove('active'));
      el.classList.add('active');
      state.activeLog = l.path;
      const t = await api('/api/logs/tail?n=400&path=' + encodeURIComponent(l.path));
      document.getElementById('log-view').textContent = t.lines.join('\n') || '(空)';
      const view = document.getElementById('log-view');
      view.scrollTop = view.scrollHeight;
    };
    list.appendChild(el);
  }
}
document.getElementById('btn-logs-refresh').onclick = refreshLogs;

// ------------------------------------------------------------------------ boot
(async function boot() {
  await loadSettings();
  await poll();
  setInterval(poll, 2500);
})();
