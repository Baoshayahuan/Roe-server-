# -*- coding: utf-8 -*-
"""Offline check for kill_self / revive_self state actions."""
import sys
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'server' / 'directory'))
sys.path.insert(0, str(ROOT / 'tools'))
from state_scene_actions_2022 import apply_state_action, validate_state_action  # noqa: E402

fails = []


def check(name, cond, detail=''):
    print(('PASS ' if cond else 'FAIL ') + name + ('' if cond else f' -> {detail}'))
    if not cond:
        fails.append(name)


class World:
    def __init__(self):
        self.hp = 640
        self.death_sent = False
        self.fixture = SimpleNamespace(hp=1000, death_on_zero=True)
        self.dead = False

    @property
    def is_dead(self):
        return False

    def poll_death(self):
        if self.death_sent or self.hp:
            return [], []
        self.death_sent = True
        return [(0x533, b'\x00' * 16)], [{'action': 'own_death'}]


state = dict(actor_uid=0x515BB187515D50, world=World(), weapon=SimpleNamespace())

# validation
check('kill_self 通过校验', validate_state_action({'id': 'a', 'action': 'kill_self'}) == {'action': 'kill_self'})
check('revive_self 通过校验', validate_state_action({'id': 'b', 'action': 'revive_self'}) == {'action': 'revive_self'})
try:
    validate_state_action({'id': 'c', 'action': 'kill_self', 'hp': 5})
    check('kill_self 拒绝多余字段', False)
except ValueError:
    check('kill_self 拒绝多余字段', True)

# apply: kill
packets, event = apply_state_action(state, {'action': 'kill_self'})
check('kill_self 发出 0x533', len(packets) == 1 and packets[0][0] == 0x533, packets)
check('kill_self hp=0', state['world'].hp == 0, state['world'].hp)
check('kill_self accepted', event.get('accepted') is True, event)

# apply: revive
packets, event = apply_state_action(state, {'action': 'revive_self'})
check('revive_self 回满血', state['world'].hp == 1000, state['world'].hp)
check('revive_self 发出 0x1069', len(packets) == 1 and packets[0][0] == 0x1069, packets)
check('revive_self 清 death_sent', state['world'].death_sent is False)

# apply: no world
check('无 world 时拒绝', apply_state_action({'actor_uid': 1}, {'action': 'kill_self'})[1].get('reason') == 'world_required')

print('\n%d failed' % len(fails))
raise SystemExit(1 if fails else 0)
