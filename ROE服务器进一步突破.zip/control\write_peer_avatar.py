# -*- coding: utf-8 -*-
"""Create config/peer-avatar.json as a template for remote players."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
base = json.loads((ROOT / 'config' / 'target-plain.json').read_text(encoding='utf-8'))
base['uid'] = '0x2040000200001'
base['speed_cm_seconds'] = 0
base['waypoints'] = [[365030, 543960, 259111]]
base['pellet_damage'] = 0
base.pop('attack', None)
base['collision_boxes'] = []
(ROOT / 'config' / 'peer-avatar.json').write_text(
    json.dumps(base, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print('written', len(base), 'keys')
