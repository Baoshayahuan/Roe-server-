# -*- coding: utf-8 -*-
"""Check that ENTER_ROOM_RSP picks up the live selection override."""
import json
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
sys.path.insert(0, str(ROOT / 'server' / 'directory'))
from room_cosmetics_2022 import apply_room_cosmetics  # noqa: E402

room_spec = json.loads((ROOT / 'config' / 'room.json').read_text(encoding='utf-8'))
token = room_spec['room_file'].split('/')[-1]
wire = json.loads((ROOT / 'config' / 'wire.json').read_text(encoding='utf-8'))[token]
payload = bytes.fromhex(wire['hex'])

# catalog copy with an empty state so the baseline has no character selected
tmp = ROOT / 'control' / 'state' / 'selftest-cosmetics'
tmp.mkdir(parents=True, exist_ok=True)
catalog = json.loads((ROOT / 'config' / 'cosmetics.json').read_text(encoding='utf-8'))
catalog['state_file'] = str(tmp / 'empty-state.json')
(ROOT / 'control' / 'state' / 'selftest-catalog.json').write_text(json.dumps(catalog), encoding='utf-8')
catalog_path = ROOT / 'control' / 'state' / 'selftest-catalog.json'

fails = []


def check(name, cond, detail=''):
    print(('PASS ' if cond else 'FAIL ') + name + ('' if cond else f' -> {detail}'))
    if not cond:
        fails.append(name)


base, appearance = apply_room_cosmetics(payload, catalog_path)
check('无选择时是默认模型', appearance['avatar_ids'] == [0, 0, 0, 0, 0], appearance)

override = {'avatar': [3501, 0, 0, 0, 0], 'avatar_applied': True, 'profile': 'baoshayahuan'}
patched, appearance2 = apply_room_cosmetics(payload, catalog_path, override)
check('覆盖后 avatar_ids 正确', appearance2['avatar_ids'] == [3501, 0, 0, 0, 0], appearance2)
check('覆盖后 applied=true', appearance2['avatar_applied'] is True, appearance2)
check('帧长度不变', len(patched) == len(base), (len(patched), len(base)))
from roe_room_2023 import decode_enter_room_response
offset = {s['name']: s for s in decode_enter_room_response(payload)['sections']}['mce6']['offset']
check('avatar 块之前的字节不变', patched[:offset] == base[:offset])
check('只有 20 字节 avatar 变化', sum(1 for a, b in zip(patched, base) if a != b) <= 20)
check('原名外的字节仍合法', isinstance(patched, bytes) and len(patched) > 1000)

# invalid override must fall back, not crash
for bad in ({'avatar': [1, 2]}, {'avatar': 'x'}, {}, {'avatar': [0, 0, 0, 0, 0], 'avatar_applied': 'yes'}):
    try:
        apply_room_cosmetics(payload, catalog_path, bad)
        ok = True
    except Exception as exc:  # noqa: BLE001
        ok = False
        print('   ', bad, '->', exc)
    check('非法覆盖被容忍 ' + str(bad)[:24], ok)

shutil.rmtree(tmp, ignore_errors=True)
print('\n%d failed' % len(fails))
raise SystemExit(1 if fails else 0)
