# -*- coding: utf-8 -*-
"""Offline checks: 3-member team body, bot points, HP floor config."""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
sys.path.insert(0, str(ROOT / 'server' / 'directory'))
from roe_team_2022 import team_body, decode_team, decode_minimal_team  # noqa: E402
from team_bots_2022 import bot_members, bot_points, bot_uids  # noqa: E402

fails = []


def check(name, cond, detail=''):
    print(('PASS ' if cond else 'FAIL ') + name + ('' if cond else f' -> {detail}'))
    if not cond:
        fails.append(name)


request = (4).to_bytes(4, 'big') + (16010).to_bytes(4, 'big') + (1).to_bytes(4, 'big') + (2).to_bytes(4, 'big')
player = 0x515BB187515D50

body = team_body(player, request, 'baoshayahuan')
value = decode_minimal_team(body)
check('单人队伍保持不变', value['uid'] == player and value['nickname'] == 'baoshayahuan')
check('单人长度 112+名字', len(body) == 112 + len('baoshayahuan') + 1, len(body))

members = bot_members(player, 'baoshayahuan', 2)
body3 = team_body(player, request, 'baoshayahuan', members=members)
value3 = decode_team(body3)
check('三人队伍可解码', len(value3['members']) == 3, value3)
check('队长是玩家', value3['members'][0] == (player, 'baoshayahuan'), value3['members'])
check('队友名字', [m[1] for m in value3['members'][1:]] == ['Bot1', 'Bot2'], value3['members'])
uids = bot_uids(2)
check('队友 UID 唯一', len(set(uids)) == 2 and all(u < 2**64 for u in uids), uids)
check('队友 UID 与玩家不同', player not in uids)
check('尾部字段保持', value3['tail'] == (2, 16010, 1, 5) and value3['unknown'] == 0, value3)

points = bot_points(2, ROOT)
check('两个出生点', len(points) == 2 and all('uid' in p and len(p['position']) == 3 for p in points), points)
check('出生点 UID 与队伍一致', [int(p['uid'], 16) for p in points] == uids, points)

world = json.loads((ROOT / 'config' / 'world.json').read_text())
check('world 有 hp_floor', 'hp_floor' in world, list(world)[:6])
world['hp_floor'] = 0
check('hp_floor 可写 0', world['hp_floor'] == 0)

print('\n%d failed' % len(fails))
raise SystemExit(1 if fails else 0)
